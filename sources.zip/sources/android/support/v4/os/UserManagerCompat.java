package android.support.v4.os;

import android.content.Context;
import android.os.Build;
import android.os.UserManager;

/* JADX INFO: loaded from: classes.dex */
public class UserManagerCompat {
    private UserManagerCompat() {
    }

    public static boolean isUserUnlocked(Context context) {
        if (Build.VERSION.SDK_INT < 24) {
            return true;
        }
        return ((UserManager) context.getSystemService(UserManager.class)).isUserUnlocked();
    }
}
