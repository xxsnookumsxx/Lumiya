package android.support.design.internal;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.design.R;
import android.support.v7.widget.LinearLayoutCompat;
import android.util.AttributeSet;
import android.view.Gravity;
import com.google.common.logging.nano.Vr;

/* JADX INFO: loaded from: classes.dex */
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class ForegroundLinearLayout extends LinearLayoutCompat {
    private Drawable mForeground;
    boolean mForegroundBoundsChanged;
    private int mForegroundGravity;
    protected boolean mForegroundInPadding;
    private final Rect mOverlayBounds;
    private final Rect mSelfBounds;

    public ForegroundLinearLayout(Context context) {
        this(context, null);
    }

    public ForegroundLinearLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ForegroundLinearLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mSelfBounds = new Rect();
        this.mOverlayBounds = new Rect();
        this.mForegroundGravity = Vr.VREvent.VrCore.ErrorCode.CONTROLLER_UNSUPPORTED;
        this.mForegroundInPadding = true;
        this.mForegroundBoundsChanged = false;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R.styleable.ForegroundLinearLayout, i, 0);
        this.mForegroundGravity = typedArrayObtainStyledAttributes.getInt(R.styleable.ForegroundLinearLayout_android_foregroundGravity, this.mForegroundGravity);
        Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(R.styleable.ForegroundLinearLayout_android_foreground);
        if (drawable != null) {
            setForeground(drawable);
        }
        this.mForegroundInPadding = typedArrayObtainStyledAttributes.getBoolean(R.styleable.ForegroundLinearLayout_foregroundInsidePadding, true);
        typedArrayObtainStyledAttributes.recycle();
    }

    @Override // android.view.View
    public void draw(@NonNull Canvas canvas) {
        super.draw(canvas);
        if (this.mForeground == null) {
            return;
        }
        Drawable drawable = this.mForeground;
        if (this.mForegroundBoundsChanged) {
            this.mForegroundBoundsChanged = false;
            Rect rect = this.mSelfBounds;
            Rect rect2 = this.mOverlayBounds;
            int right = getRight() - getLeft();
            int bottom = getBottom() - getTop();
            if (this.mForegroundInPadding) {
                rect.set(0, 0, right, bottom);
            } else {
                rect.set(getPaddingLeft(), getPaddingTop(), right - getPaddingRight(), bottom - getPaddingBottom());
            }
            Gravity.apply(this.mForegroundGravity, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), rect, rect2);
            drawable.setBounds(rect2);
        }
        drawable.draw(canvas);
    }

    @Override // android.view.View
    @RequiresApi(21)
    public void drawableHotspotChanged(float f, float f2) {
        super.drawableHotspotChanged(f, f2);
        if (this.mForeground == null) {
            return;
        }
        this.mForeground.setHotspot(f, f2);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        if (this.mForeground != null && this.mForeground.isStateful()) {
            this.mForeground.setState(getDrawableState());
        }
    }

    @Override // android.view.View
    public Drawable getForeground() {
        return this.mForeground;
    }

    @Override // android.view.View
    public int getForegroundGravity() {
        return this.mForegroundGravity;
    }

    @Override // android.view.ViewGroup, android.view.View
    @RequiresApi(11)
    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        if (this.mForeground == null) {
            return;
        }
        this.mForeground.jumpToCurrentState();
    }

    @Override // android.support.v7.widget.LinearLayoutCompat, android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        this.mForegroundBoundsChanged |= z;
    }

    @Override // android.view.View
    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        this.mForegroundBoundsChanged = true;
    }

    @Override // android.view.View
    public void setForeground(Drawable drawable) {
        if (this.mForeground == drawable) {
            return;
        }
        if (this.mForeground != null) {
            this.mForeground.setCallback(null);
            unscheduleDrawable(this.mForeground);
        }
        this.mForeground = drawable;
        if (drawable == null) {
            setWillNotDraw(true);
        } else {
            setWillNotDraw(false);
            drawable.setCallback(this);
            if (drawable.isStateful()) {
                drawable.setState(getDrawableState());
            }
            if (this.mForegroundGravity == 119) {
                drawable.getPadding(new Rect());
            }
        }
        requestLayout();
        invalidate();
    }

    @Override // android.view.View
    public void setForegroundGravity(int i) {
        if (this.mForegroundGravity == i) {
            return;
        }
        int i2 = (8388615 & i) != 0 ? i : 8388611 | i;
        if ((i2 & 112) == 0) {
            i2 |= 48;
        }
        this.mForegroundGravity = i2;
        if (this.mForegroundGravity == 119 && this.mForeground != null) {
            this.mForeground.getPadding(new Rect());
        }
        requestLayout();
    }

    @Override // android.view.View
    protected boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.mForeground;
    }
}
